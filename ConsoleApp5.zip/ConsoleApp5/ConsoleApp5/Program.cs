﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class Program
    {
        

        class Programa
        {
            // Definimos el arreglo de objetos Producto con un tamaño máximo de 5
            static Producto[] inventario = new Producto[5];
            // Contador para saber cuántos productos reales hemos registrado
            static int numProductosRegistrados = 0;

            static void Main(string[] args)
            {
                int opcion;

                do
                {
                    MostrarMenu();
                    if (int.TryParse(Console.ReadLine(), out opcion))
                    {
                        EjecutarOpcion(opcion);
                    }
                    else
                    {
                        Console.WriteLine(" Opción no válida. Ingrese un número del 1 al 5.");
                    }
                    Console.WriteLine("\nPresione una tecla para continuar...");
                    Console.ReadKey();
                    Console.Clear();
                } while (opcion != 5);
            }

            static void MostrarMenu()
            {
                Console.WriteLine("===============================");
                Console.WriteLine("  SISTEMA BÁSICO DE VENTAS  ");
                Console.WriteLine("===============================");
                Console.WriteLine("1. Registrar producto (Máx. 5)");
                Console.WriteLine("2. Listar productos y Total General");
                Console.WriteLine("3. Buscar producto por nombre");
                Console.WriteLine("4. Modificar precio de producto");
                Console.WriteLine("5. Salir del programa");
                Console.Write("Seleccione una opción: ");
            }

            static void EjecutarOpcion(int opcion)
            {
                switch (opcion)
                {
                    case 1:
                        RegistrarProducto();
                        break;
                    case 2:
                        ListarProductosYTotal();
                        break;
                    case 3:
                        BuscarProducto();
                        break;
                    case 4:
                        ModificarPrecio();
                        break;
                    case 5:
                        Console.WriteLine("Saliendo del sistema. ¡Hasta pronto!");
                        break;
                    default:
                        Console.WriteLine("Opción fuera de rango.");
                        break;
                }
            }

            // 1. Registrar producto
            static void RegistrarProducto()
            {
                if (numProductosRegistrados >= inventario.Length)
                {
                    Console.WriteLine("El inventario está lleno. Límite de 5 productos alcanzado.");
                    return;
                }

                Console.WriteLine("\n--- Registro de Nuevo Producto ---");

                Console.Write("Nombre del producto: ");
                string nombre = Console.ReadLine();

                Console.Write("Cantidad vendida: ");
                int cantidad = int.Parse(Console.ReadLine());

                Console.Write("Precio unitario: ");
                decimal precio = decimal.Parse(Console.ReadLine());

                inventario[numProductosRegistrados] = new Producto(nombre, cantidad, precio);
                numProductosRegistrados++;

                Console.WriteLine("Producto registrado con éxito.");
            }

            // 2. Listar productos y Total General
            static void ListarProductosYTotal()
            {
                if (numProductosRegistrados == 0)
                {
                    Console.WriteLine("No hay productos registrados para listar.");
                    return;
                }

                decimal totalGeneral = 0;
                Console.WriteLine("\n--- Lista de Productos Vendidos ---");

                for (int i = 0; i < numProductosRegistrados; i++)
                {
                    Producto p = inventario[i];
                    Console.WriteLine($"\n[ID: {i}] Nombre: *{p.Nombre}, Cant.: {p.CantidadVendida}, P. Unit.: {p.PrecioUnitario:C}, **Subtotal: {p.Subtotal:C}*");
                    totalGeneral += p.Subtotal;
                }

                Console.WriteLine("\n------------------------------------");
                Console.WriteLine($"*TOTAL GENERAL DE LA VENTA: {totalGeneral:C}*");
                Console.WriteLine("------------------------------------");
            }

            // 3. Buscar producto por nombre
            static void BuscarProducto()
            {
                if (numProductosRegistrados == 0)
                {
                    Console.WriteLine("No hay productos registrados para buscar.");
                    return;
                }

                Console.Write("\nIngrese el nombre del producto a buscar: ");
                string nombreBuscar = Console.ReadLine().Trim().ToLower();

                // Buscamos el producto en el arreglo
                Producto encontrado = null;
                for (int i = 0; i < numProductosRegistrados; i++)
                {
                    if (inventario[i].Nombre.ToLower().Equals(nombreBuscar))
                    {
                        encontrado = inventario[i];
                        break; 
                    }
                }

                if (encontrado != null)
                {
                    Console.WriteLine("Producto encontrado:");
                    encontrado.MostrarDetalle();
                }
                else
                {
                    Console.WriteLine($"Producto '{nombreBuscar}' no encontrado.");
                }
            }

            // 4. Modificar precio de producto
            static void ModificarPrecio()
            {
                if (numProductosRegistrados == 0)
                {
                    Console.WriteLine("No hay productos registrados para modificar.");
                    return;
                }

                Console.Write("\nIngrese el nombre del producto cuyo precio desea modificar: ");
                string nombreModificar = Console.ReadLine().Trim().ToLower();

                Producto productoAEditar = null;
                int indice = -1;

                // Buscar el producto por nombre y guardar su índice
                for (int i = 0; i < numProductosRegistrados; i++)
                {
                    if (inventario[i].Nombre.ToLower().Equals(nombreModificar))
                    {
                        productoAEditar = inventario[i];
                        indice = i;
                        break;
                    }
                }

                if (productoAEditar != null)
                {
                    Console.WriteLine($"Producto actual: *{productoAEditar.Nombre}*, Precio actual: {productoAEditar.PrecioUnitario:C}");
                    Console.Write("Ingrese el nuevo precio unitario: ");

                    if (decimal.TryParse(Console.ReadLine(), out decimal nuevoPrecio))
                    {
                        // Modificar el precio directamente en el objeto
                        productoAEditar.PrecioUnitario = nuevoPrecio;

                        // El subtotal se recalcula automáticamente gracias a la propiedad 'Subtotal'
                        Console.WriteLine("Precio modificado con éxito.");
                        Console.WriteLine($"Nuevo Subtotal: *{productoAEditar.Subtotal:C}*");
                    }
                    else
                    {
                        Console.WriteLine("Precio no válido.");
                    }
                }
                else
                {
                    Console.WriteLine($"Producto '{nombreModificar}' no encontrado.");
                }
            }
        }

        public class Producto
        {
            // Propiedades del producto
            public string Nombre { get; set; }
            public int CantidadVendida { get; set; }
            public decimal PrecioUnitario { get; set; }

            // Propiedad calculada
            public decimal Subtotal
            {
                get { return CantidadVendida * PrecioUnitario; }
            }

            public Producto(string nombre, int cantidad, decimal precio)
            {
                Nombre = nombre;
                CantidadVendida = cantidad;
                PrecioUnitario = precio;
            }

            // Método para mostrar la información del producto
            public void MostrarDetalle()
            {
                Console.WriteLine($"\n--- Detalle del Producto ---");
                Console.WriteLine($"Nombre: {Nombre}");
                Console.WriteLine($"Cantidad: {CantidadVendida}");
                Console.WriteLine($"Precio Unitario: {PrecioUnitario:C}");
                Console.WriteLine($"Subtotal: {Subtotal:C}");
                Console.WriteLine("----------------------------");
            }
        }
    }
}
